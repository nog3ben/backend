const HomeController = require("./HomeController");

class Controller {
  constructor(req, res) {
    // this.controllerInterface();
    this.req = req;
    this.res = res;
    this.methodSelector();
  }

  controllerInterface() {
    if (
      typeof this.index !== "function" ||
      typeof this.store !== "function" ||
      typeof this.update !== "function" ||
      typeof this.delete !== "function"
    ) {
      throw new Error("Api resource not implemented");
    }
  }

  methodSelector() {
    switch (this.req.method) {
      case "GET":
        this.index();
        break;

      case "POST":
        this.store();
        break;

      case "PUT":
        this.update();
        break;

      case "DELETE":
        this.delete();
        break;

      default:
        this.methodNotAllowed();
        break;
    }
  }

  methodNotAllowed() {
    this.res.send("Method not allowed");
  }
}

module.exports = Controller;
